# Changelog

## 1.2.0
- Every page and every player row / kill log button can be switched off in P menu > Mods > Easier Admin, like AdminHelper.
- Confirmation messages after each action (given to how many players, slain with what reason, and so on); can be turned off.
- Weapon names in loadouts are checked; unknown names are reported instead of silently doing nothing.
- Quick slay buttons are named Slay (reason 1, 2, 3) so they always match the reasons you set.
- Sliders send once you let go instead of flooding the server; new Apply all to server button.
- Fun Settings page starts at the game's defaults each launch.
- Messages when a macro, loadout or scheduled command is empty, or nobody wears the regiment tag.
- Fixed a leftover table at the end of the Hotkeys section of this readme.

## 1.1.1
- Ask to swap sides now sends: <regiment tag> please swap sides for the remainder of the event!!

## 1.1.0
- Hotkeys can be set in game on the new Hotkeys page: click an action, press a key (Ctrl / Shift / Alt combinations work).
- 13 actions can have a key: macros, giving weapons and loadouts, keep giving, strip all, broadcasts, god mode, firing and the team count.
- Hotkeys are ignored while typing in chat.

## 1.0.0
- First release: Weapons, Fun Settings, Admin and Players pages, player row and kill log actions, hotkeys and a live team count.
