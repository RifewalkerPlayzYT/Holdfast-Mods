# Changelog

## 1.3.0
- Warnings: a Warn button on player rows and the kill log sends the player "Admin warning 2/3: <reason>" and counts warnings for the night. Optional (off by default): share warnings in admin chat so every admin running Easier Admin keeps the same tally. At the last warning you get a one-click Slay / Kick box.
- Chat alerts: chat that mentions admin, report, teamkill, rambo, FIC (or your own words), and anything said by a player you watch, is highlighted and listed on screen. New Watch in chat button on player rows.
- FIC tags: a firearm kill on an enemy who was in melee with the shooter's own side gets a red [FIC?] tag in the admin kill log, an on-screen alert and a per-player count for the round.
- Teamkill tracker: every teamkill is counted per player for the night, tagged [TK 2] in the admin kill log and shown as an alert. At the limit (default 3) a box offers Warn, Slay or Kick. Artillery and explosion teamkills only count if you switch that on.
- Nothing is automatic: Easier Admin never warns, slays, kicks or messages anyone by itself. Every action is a button you click, and Kick (warnings) asks for a second click.
- More game settings: weapon damage, walk speed, horse jump, cannon loading speed, allow blocking, bullet drop, infinite range, horse for everyone and force first person.

## 1.2.0
- Every page and every player row / kill log button can be switched off in P menu > Mods > Easier Admin, like AdminHelper.
- Confirmation messages after each action (given to how many players, slain with what reason, and so on); can be turned off.
- Weapon names in loadouts are checked; unknown names are reported instead of silently doing nothing.
- Quick slay buttons are named Slay (reason 1, 2, 3) so they always match the reasons you set.
- Sliders send once you let go instead of flooding the server; new Apply all to server button.
- Fun Settings page starts at the game's defaults each launch.
- Messages when a macro, loadout or scheduled command is empty, or nobody wears the regiment tag.
- Fixed a leftover table at the end of the Hotkeys section of this readme.

## 1.1.1
- Ask to swap sides now sends: <regiment tag> please swap sides for the remainder of the event!!

## 1.1.0
- Hotkeys can be set in game on the new Hotkeys page: click an action, press a key (Ctrl / Shift / Alt combinations work).
- 13 actions can have a key: macros, giving weapons and loadouts, keep giving, strip all, broadcasts, god mode, firing and the team count.
- Hotkeys are ignored while typing in chat.

## 1.0.0
- First release: Weapons, Fun Settings, Admin and Players pages, player row and kill log actions, hotkeys and a live team count.
