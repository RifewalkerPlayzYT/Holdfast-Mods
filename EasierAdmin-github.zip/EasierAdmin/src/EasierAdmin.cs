// Easier Admin - a client-side admin helper for Holdfast: Nations At War (BepInEx, built on RyLib).
// Created by llstarlessll (Discord).
// Everything it does goes through the normal rc commands, so it only works for a player logged in with rc login.
using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx;
using BepInEx.Configuration;
using HoldfastGame;
using RyLib;
using UnityEngine;
using HarmonyLib;

namespace EasierAdmin
{
    public enum Weapon
    {
        // muskets and rifles
        Musket_Land_Pattern_Musket_Brown_Bess, Musket_Charleville_Musket_IXXIII_Standard_Year, Musket_Russian_Musket_Pattern_1808, Musket_Spanish_Escopeta_Musket,
        Musket_Ottoman_Tufenk_Musket, Musket_Boutet_Musket, Musket_Iroquois_Musket, Musket_Barbary,
        Rifle_Baker_Rifle_Pattern_1800, Rifle_Russian_Rifle_Pattern_1806, Rifle_Sporting_Rifle, Rifle_Long_Rifle,
        Carbine_Elliot_Carbine, Carbine_Charleville_Cavalry_Carbine_IXXIII, Carbine_Russian_Cuirassier_Carbine, Carbine_Sporting_Carbine,
        Blunderbuss_French_Blunderbuss, Blunderbuss_Nock_Gun_Blunderbuss,
        // pistols and revolvers
        Pistol_Land_Pattern_Pistol, Pistol_French_Pistol_XIII, Pistol_Russian_1809_Pistol, Pistol_Le_Page_Pistol, Pistol_Nelson,
        Frontlines_Webley_Revolver_MKIV, Frontlines_Modele_1892_Revolver, Frontlines_M1917_Revolver, Frontlines_Mauser_C78_Revolver,
        // WW1 rifles
        Frontlines_LeeEnfield_MKIII, Frontlines_Mauser_Gewehr_98, Frontlines_Lebel_Model_1886,
        // swords
        Sword_British_Officer_Sword, Sword_American_Officer_Sword, Sword_Dragoon_Sword, Sword_1796_Pattern_Light_Sabre, Sword_Russian_Hussar_Sword,
        Sword_An_XI_Light_Sabre, Sword_Sabre_Briquet, Sword_British_Hanger, Sword_French_Hanger, Sword_1804_Pattern_Naval_Cutlass, Sword_Claymore,
        Sword_Scimitar, Sword_Yatagan_Sword, Sword_Napoleons_Sword, Sword_Battle_Axe, Sword_War_Hammer, Sword_Tomahawk,
        // axes, pikes, knives, clubs
        Axe2H_British_2Handed_Axe, Axe2H_Sapper_2Handed_Axe, Axe1H_Carpenter_Axe, Axe2H_The_Log,
        Spontoon_Pitchfork, Spontoon_Halberd, Spontoon_British_Spontoon, Spontoon_British_Boarding_Pike,
        Knife_British_Dagger, Knife_French_Knife, Frontlines_British_Trench_Club, Frontlines_1918_Trench_Knife,
        // just for fun
        Sword_Frying_Pan, Sword_Frying_Pan_Gold, Sword_Whiskey_Bottle, Sword_Rum_Bottle, Sword_Peg_Leg
    }

    [BepInPlugin(Guid, "Easier Admin", "1.3.0")]
    [BepInDependency("com.ryannlt.rylib", "1.2.0")]
    public class EasierAdminPlugin : BaseUnityPlugin
    {
        public const string Guid = "com.llstarlessll.easieradmin";
        static EasierAdminPlugin I;

        // weapons
        ConfigEntry<Weapon> pick; ConfigEntry<bool> keepGiving, includeBots; ConfigEntry<string>[] loadouts;
        // fun settings
        ConfigEntry<float> runSpeed, jumpForce, explosionSize, explosionKnock, ragdoll;
        ConfigEntry<bool> explosive, infiniteAmmo, godMode, fallDamage, allowFiring, allowArty;
        ConfigEntry<string> schedCommand; ConfigEntry<int> schedDelay;
        // admin
        ConfigEntry<string>[] broadcasts, macroText; ConfigEntry<string>[] slayReasons;
        // players
        ConfigEntry<string> regTag, regMessage; ConfigEntry<bool> teamCount;
        // hotkeys: every action an admin can bind to a key (with Ctrl / Shift / Alt if wanted), set in game
        class Hotkey { public string Name; public ConfigEntry<KeyboardShortcut> Key; public Action Run; }
        readonly List<Hotkey> hotkeys = new List<Hotkey>();
        Hotkey listening; float listenUntil;

        // feature switches (P menu > Mods > Easier Admin), like AdminHelper's settings
        ConfigEntry<bool> fWeapons, fFun, fAdmin, fPlayers, fHotkeys, fRowGive, fRowLoadout, fRowStrip, fRowSlay, fKillLog, fFeedback;
        readonly Dictionary<string, KeyValuePair<float, string>> pendingSet = new Dictionary<string, KeyValuePair<float, string>>();
        List<P> cache = new List<P>(); float cacheAt;
        bool suppress;
        readonly HashSet<int> wasAlive = new HashSet<int>();
        readonly List<KeyValuePair<float, int>> pendingGive = new List<KeyValuePair<float, int>>();
        readonly List<KeyValuePair<float, string>> scheduled = new List<KeyValuePair<float, string>>();
        float nextPoll;

        // 1.3.0: more fun settings
        ConfigEntry<float> dmgScale, walkSpeed, horseJump, cannonLoad;
        ConfigEntry<bool> allowBlock, bulletDrop, infRange, horseAll, firstPerson;
        // 1.3.0: chat alerts
        ConfigEntry<bool> fAlerts; ConfigEntry<string> alertWords, watchNames;
        // 1.3.0: warnings
        ConfigEntry<bool> fWarn, shareWarns; ConfigEntry<int> warnMax; ConfigEntry<string> warnReason, warnStore;
        // 1.3.0: FIC tags in the kill log
        ConfigEntry<bool> fFic, ficAlert; ConfigEntry<float> ficMeleeRange, ficShooterMin;
        static readonly List<Alert> alerts = new List<Alert>();
        class Alert { public float Until; public string Text; }
        static readonly Dictionary<string, int> warns = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        static readonly Dictionary<string, int> ficCount = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        static int offerId = -1; static string offerName, offerText, offerReason; static bool offerWarn; static float offerUntil;
        // 1.3.0: teamkill tracker
        ConfigEntry<bool> fTk, tkAlert, tkArty; ConfigEntry<int> tkMax; ConfigEntry<string> tkStore;
        static readonly Dictionary<string, int> tks = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        void Awake()
        {
            I = this;
            BindConfig();
            ResetFunDisplay();
            AddHotkeys();
            BuildMenu();
            Patch();
            Logger.LogInfo("Easier Admin 1.3.0 loaded (by llstarlessll)");
        }

        // ------------------------------------------------------------------ config
        void BindConfig()
        {
            pick = Config.Bind("Weapons", "Weapon", Weapon.Spontoon_Pitchfork, "The weapon the Give buttons hand out.");
            keepGiving = Config.Bind("Weapons", "KeepGivingOnRespawn", false, "While on, every player who respawns is given the chosen weapon (only while you are in the server).");
            includeBots = Config.Bind("Weapons", "IncludeBots", false, "Also give weapons to bots.");
            loadouts = new ConfigEntry<string>[3];
            string[] defs = { "Spontoon_Pitchfork,Pistol_Land_Pattern_Pistol", "Sword_1796_Pattern_Light_Sabre", "Sword_Frying_Pan" };
            for (int i = 0; i < 3; i++) loadouts[i] = Config.Bind("Loadouts", "Loadout" + (i + 1), defs[i], "Weapons for loadout " + (i + 1) + ", comma separated weapon names.");

            runSpeed = Fun("RunSpeed", 1f, "characterRunSpeed", "Run speed multiplier (1 = normal).");
            jumpForce = Fun("JumpForce", 1f, "characterJumpForce", "Jump force multiplier (1 = normal).");
            explosionSize = Fun("ExplosionSize", 1f, "explosionScaleMultiplier", "Explosion size multiplier (1 = normal).");
            explosionKnock = Fun("ExplosionKnockback", 1f, "explosionKnockbackForceMultiplier", "Explosion knockback multiplier (1 = normal).");
            ragdoll = Fun("RagdollForce", 1f, "ragdollForceMultiplier", "Ragdoll force multiplier (1 = normal).");
            explosive = FunB("ExplosiveFirearms", false, "characterExplosiveFirearms", "Every shot explodes.");
            infiniteAmmo = FunB("InfiniteAmmo", false, "characterInfiniteFirearmAmmo", "Infinite firearm ammo.");
            godMode = FunB("GodMode", false, "characterGodMode", "Nobody can be hurt.");
            fallDamage = FunB("FallDamage", true, "characterFallDamageEnabled", "Fall damage on or off.");
            allowFiring = FunB("AllowFiring", true, "allowFiring", "Players may fire.");
            allowArty = FunB("AllowArtilleryFiring", true, "allowArtyFiring", "Artillery may fire.");
            schedCommand = Config.Bind("Scheduler", "Command", "broadcast CHARGE!", "rc command(s) to run later, without the rc. Separate several with ;");
            schedDelay = Config.Bind("Scheduler", "DelaySeconds", 60, new ConfigDescription("Seconds from now.", new AcceptableValueRange<int>(5, 1800)));

            broadcasts = new ConfigEntry<string>[3];
            string[] bdef = { "Lines raise in 1 minute!", "No firing until LIVE!", "Thanks for playing! Next battle soon." };
            for (int i = 0; i < 3; i++) broadcasts[i] = Config.Bind("Admin", "Broadcast" + (i + 1), bdef[i], "Broadcast template " + (i + 1) + ".");
            macroText = new ConfigEntry<string>[2];
            macroText[0] = Config.Bind("Admin", "Macro1", "set characterGodMode false; set allowFiring true; broadcast LIVE!", "Macro 1 (Go live): rc commands separated by ;");
            macroText[1] = Config.Bind("Admin", "Macro2", "ac 30", "Macro 2 (All charge): rc commands separated by ;");
            slayReasons = new ConfigEntry<string>[3];
            string[] sdef = { "Out of line", "Firing before LIVE", "Teamkilling" };
            for (int i = 0; i < 3; i++) slayReasons[i] = Config.Bind("Admin", "SlayReason" + (i + 1), sdef[i], "Reason for quick slay button " + (i + 1) + " on the player row.");

            fWeapons = Config.Bind("Features", "WeaponsPage", true, "Show the Weapons page.");
            fFun = Config.Bind("Features", "FunSettingsPage", true, "Show the Fun Settings page.");
            fAdmin = Config.Bind("Features", "AdminPage", true, "Show the Admin page.");
            fPlayers = Config.Bind("Features", "PlayersPage", true, "Show the Players page.");
            fHotkeys = Config.Bind("Features", "Hotkeys", true, "Hotkeys on or off (the Hotkeys page hides when off).");
            fRowGive = Config.Bind("Features", "RowGiveWeapon", true, "Give weapon button on player rows and the kill log.");
            fRowLoadout = Config.Bind("Features", "RowGiveLoadout", true, "Give loadout 1 button on player rows and the kill log.");
            fRowStrip = Config.Bind("Features", "RowStripWeapons", true, "Strip weapons button on player rows and the kill log.");
            fRowSlay = Config.Bind("Features", "RowQuickSlays", true, "The three quick slay buttons on player rows and the kill log.");
            fKillLog = Config.Bind("Features", "KillLogActions", true, "Turn on the kill log action panel (also shared with other RyLib mods).");
            fFeedback = Config.Bind("Features", "ConfirmMessages", true, "Send yourself a private message confirming each action (given to X players, scheduled, and so on).");
            regTag = Config.Bind("Players", "RegimentTag", "", "Regiment tag to message.");
            regMessage = Config.Bind("Players", "RegimentMessage", "Please listen to the admins.", "Message for the regiment.");
            teamCount = Config.Bind("Players", "ShowTeamCount", false, "Show a live team count box on screen.");

            dmgScale = Fun("WeaponDamage", 1f, "characterWeaponDamageScale", "Weapon damage multiplier (1 = normal).");
            walkSpeed = Fun("WalkSpeed", 1f, "characterWalkSpeed", "Walk speed multiplier (1 = normal).");
            horseJump = Fun("HorseJump", 1f, "vehicleJumpHeightMultiplier", "Horse jump height multiplier (1 = normal).");
            cannonLoad = Fun("CannonLoading", 1f, "cannonLoadingSpeedMultiplier", "Cannon, rocket and machine gun loading speed (1 = normal).");
            allowBlock = FunB("AllowBlocking", true, "allowBlocking", "Players can block with melee weapons.");
            bulletDrop = FunB("BulletDrop", true, "characterWeaponFirearmApplyDrop", "Bullets drop over distance.");
            infRange = FunB("InfiniteRange", false, "characterWeaponInfiniteRange", "Firearms hit at any range.");
            horseAll = FunB("HorseForEveryone", false, "vehicleHorseForAll", "Everyone spawns with a horse.");
            firstPerson = FunB("ForceFirstPerson", false, "forceFirstPersonMode", "Everyone has to play in first person.");

            fAlerts = Config.Bind("ChatAlerts", "On", true, "Highlight chat messages that mention admin, a watched player or one of your words.");
            alertWords = Config.Bind("ChatAlerts", "Words", "admin, report, help, tk, teamkill, rambo, fic, hack, cheat", "Words that trigger an alert, comma separated (capitals don't matter).");
            watchNames = Config.Bind("ChatAlerts", "WatchedPlayers", "", "Player names to watch, comma separated. Anything they say is highlighted.");

            fWarn = Config.Bind("Warnings", "On", true, "Warn button on player rows and the kill log.");
            warnMax = Config.Bind("Warnings", "MaxWarnings", 3, new ConfigDescription("At this many warnings you are offered a one-click slay or kick.", new AcceptableValueRange<int>(1, 10)));
            warnReason = Config.Bind("Warnings", "Reason", "Follow the event rules", "Reason sent with each warning.");
            shareWarns = Config.Bind("Warnings", "ShareInAdminChat", false, "Also post each warning and kick in admin chat (only logged-in admins see it) so other admins' Easier Admin keeps the same count. Off by default.");
            warnStore = Config.Bind("Warnings", "Tonight", "", "Saved warning counts for tonight (filled in by Easier Admin).");

            fFic = Config.Bind("FIC", "On", true, "Tag kill log rows where someone shot into a melee their own side was in (firing in charge).");
            ficAlert = Config.Bind("FIC", "Alert", true, "Also show an on-screen alert for each possible FIC.");
            ficMeleeRange = Config.Bind("FIC", "MeleeRange", 3f, new ConfigDescription("A teammate of the shooter this close (metres) to the victim counts as being in melee with them.", new AcceptableValueRange<float>(1f, 8f)));
            ficShooterMin = Config.Bind("FIC", "ShooterDistance", 4f, new ConfigDescription("The shooter must be at least this far (metres) from the victim, so point-blank fights in the melee itself don't count.", new AcceptableValueRange<float>(0f, 20f)));
            fTk = Config.Bind("Teamkills", "On", true, "Count teamkills per player for the night and tag them in the kill log.");
            tkAlert = Config.Bind("Teamkills", "Alert", true, "Show an on-screen alert for every teamkill.");
            tkArty = Config.Bind("Teamkills", "CountArtillery", false, "Also count teamkills by artillery, rockets, explosions and horses (off: only shots and melee).");
            tkMax = Config.Bind("Teamkills", "Limit", 3, new ConfigDescription("At this many teamkills you are offered a one-click warn, slay or kick.", new AcceptableValueRange<int>(1, 10)));
            tkStore = Config.Bind("Teamkills", "Tonight", "", "Saved teamkill counts for tonight (filled in by Easier Admin).");
            LoadWarns(); LoadCounts(tkStore, tks);

            // actions are filled in once everything else is bound (see AddHotkeys)
        }

        void AddHotkeys()
        {
            HK("Macro1", "Run macro 1 (Go live)", new KeyboardShortcut(KeyCode.F9), () => RunMacro(0));
            HK("Macro2", "Run macro 2 (All charge)", new KeyboardShortcut(KeyCode.F10), () => RunMacro(1));
            HK("GiveWeaponToAll", "Give the chosen weapon to everyone", new KeyboardShortcut(KeyCode.F11), () => GiveAll(new[] { pick.Value.ToString() }));
            for (int i = 0; i < 3; i++) { int k = i; HK("GiveLoadout" + (k + 1), "Give loadout " + (k + 1) + " to everyone", KeyboardShortcut.Empty, () => GiveAll(Split(loadouts[k].Value))); }
            HK("ToggleKeepGiving", "Turn keep giving on respawn on or off", KeyboardShortcut.Empty, () => { keepGiving.Value = !keepGiving.Value; Tell("Keep giving on respawn: " + (keepGiving.Value ? "ON" : "OFF")); });
            HK("StripAll", "Strip everyone's weapons", KeyboardShortcut.Empty, StripAll);
            for (int i = 0; i < 3; i++) { int k = i; HK("Broadcast" + (k + 1), "Send broadcast template " + (k + 1), KeyboardShortcut.Empty, () => Rc("broadcast " + broadcasts[k].Value)); }
            HK("ToggleGodMode", "Turn god mode on or off", KeyboardShortcut.Empty, () => godMode.Value = !godMode.Value);
            HK("ToggleFiring", "Turn allow firing on or off", KeyboardShortcut.Empty, () => allowFiring.Value = !allowFiring.Value);
            HK("ToggleTeamCount", "Show or hide the team count", KeyboardShortcut.Empty, () => teamCount.Value = !teamCount.Value);
        }
        void HK(string key, string name, KeyboardShortcut def, Action run)
        {
            var e = Config.Bind("Hotkeys", key, def, name + ". Set it in game: P menu > Easier Admin > Hotkeys page. AdminHelper uses F6, [ and ].");
            hotkeys.Add(new Hotkey { Name = name, Key = e, Run = run });
        }

        // tell only yourself (a private message from the server to you)
        static void Tell(string text)
        {
            var c = ClientComponentReferenceManager.ClientInstance;
            I.Logger.LogInfo(text);
            if (!I.fFeedback.Value) return;
            if (c == null || c.clientRoundPlayerManager == null || c.clientRoundPlayerManager.LocalPlayer == null || !Admin) return;
            c.pMenuPanel.ManualConsoleExecute("rc serverAdmin privateMessage " + c.clientRoundPlayerManager.LocalPlayer.NetworkPlayerID + " " + text);
        }

        static string KeyText(KeyboardShortcut k) { return k.MainKey == KeyCode.None ? "not set" : k.ToString(); }

        ConfigEntry<float> Fun(string key, float def, string rcName, string desc)
        {
            var e = Config.Bind("FunSettings", key, def, new ConfigDescription(desc, new AcceptableValueRange<float>(0f, 10f)));
            e.SettingChanged += (s, a) => { if (!suppress && Admin) pendingSet[rcName] = new KeyValuePair<float, string>(Time.unscaledTime + 0.4f, "set " + rcName + " " + e.Value.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture)); };
            return e;
        }
        ConfigEntry<bool> FunB(string key, bool def, string rcName, string desc)
        {
            var e = Config.Bind("FunSettings", key, def, desc);
            e.SettingChanged += (s, a) => { if (!suppress && Admin) Rc("set " + rcName + " " + (e.Value ? "true" : "false")); };
            return e;
        }

        // ------------------------------------------------------------------ menu
        void BuildMenu()
        {
            var head = PMenu.Header(Guid, "Easier Admin", StockIcon.Admin);

            var weapons = head.Page(Guid, "Weapons", StockIcon.Skull, true, () => fWeapons.Value);
            weapons.Section(Guid, "Give a weapon", s =>
            {
                s.Button("Give to everyone", () => GiveAll(new[] { pick.Value.ToString() }), StockIcon.Players, "Gives the chosen weapon to every living player.");
                s.ConfirmButton("Take from everyone", () => TakeAll(pick.Value.ToString()), StockIcon.Skull, "Takes the chosen weapon away from every living player.");
                s.ConfirmButton("Strip everyone", StripAll, StockIcon.Skull, "Removes every weapon from every living player (they keep their fists).");
                s.Toggle("Keep giving on respawn", keepGiving, StockIcon.Players);
                s.Toggle("Include bots", includeBots);
                s.Dropdown("Weapon", pick, w => Nice(w.ToString()));
            });
            weapons.Section(Guid, "Loadouts", s =>
            {
                for (int i = 0; i < 3; i++) { int k = i; s.Button("Give loadout " + (k + 1) + " to all", () => GiveAll(Split(loadouts[k].Value)), StockIcon.Players); }
                for (int i = 0; i < 3; i++) s.TextField("Loadout " + (i + 1), loadouts[i]);
            });

            var fun = head.Page(Guid, "Fun Settings", StockIcon.RayGun, true, () => fFun.Value);
            fun.Section(Guid, "Game settings", s =>
            {
                s.Toggle("Explosive firearms", explosive); s.Toggle("Infinite ammo", infiniteAmmo); s.Toggle("God mode", godMode);
                s.Toggle("Fall damage", fallDamage); s.Toggle("Allow firing", allowFiring); s.Toggle("Allow artillery", allowArty);
                s.ConfirmButton("Reset to default", ResetFun, null, "Sends rc set default and puts every setting back.");
                s.Button("Apply all to server", ApplyAllFun, null, "Sends every switch and slider as shown here, so the server matches the page (the page cannot read the server's current settings).");
                s.Slider("Run speed", runSpeed, 0.2f, 5f, 0.1f); s.Slider("Jump force", jumpForce, 0.2f, 10f, 0.1f);
                s.Slider("Explosion size", explosionSize, 0.2f, 10f, 0.1f); s.Slider("Explosion knockback", explosionKnock, 0f, 10f, 0.1f);
                s.Slider("Ragdoll force", ragdoll, 0f, 10f, 0.1f);
            });
            fun.Section(Guid, "More game settings", s =>
            {
                s.Toggle("Allow blocking", allowBlock); s.Toggle("Bullet drop", bulletDrop); s.Toggle("Infinite range", infRange);
                s.Toggle("Horse for everyone", horseAll); s.Toggle("Force first person", firstPerson);
                s.Slider("Weapon damage", dmgScale, 0.1f, 5f, 0.1f); s.Slider("Walk speed", walkSpeed, 0.2f, 5f, 0.1f);
                s.Slider("Horse jump", horseJump, 0.2f, 5f, 0.1f); s.Slider("Cannon loading speed", cannonLoad, 0.2f, 5f, 0.1f);
            });
            fun.Section(Guid, "Scheduled commands", s =>
            {
                s.Button("Schedule", () => Schedule(schedCommand.Value, schedDelay.Value), null, "Runs the command after the delay (only while you are in the server).");
                s.ConfirmButton("Cancel all", () => { scheduled.Clear(); Tell("Easier Admin: scheduled commands cancelled."); });
                s.TextField("Command (no rc)", schedCommand);
                s.Slider("Delay (seconds)", schedDelay, 5, 1800);
            });

            var admin = head.Page(Guid, "Admin", StockIcon.Admin, true, () => fAdmin.Value);
            admin.Section(Guid, "Macros", s =>
            {
                s.Button("Run macro 1", () => RunMacro(0)); s.Button("Run macro 2", () => RunMacro(1));
                s.TextField("Macro 1", macroText[0]); s.TextField("Macro 2", macroText[1]);
            });
            admin.Section(Guid, "Broadcasts", s =>
            {
                for (int i = 0; i < 3; i++) { int k = i; s.Button("Send " + (k + 1), () => Rc("broadcast " + broadcasts[k].Value)); }
                for (int i = 0; i < 3; i++) s.TextField("Template " + (i + 1), broadcasts[i]);
            });
            admin.Section(Guid, "Quick slay reasons (player row buttons Slay reason 1, 2, 3)", s => { for (int i = 0; i < 3; i++) s.TextField("Reason " + (i + 1), slayReasons[i]); });
            admin.Section(Guid, "Warnings (Warn button on player rows and the kill log)", s =>
            {
                s.Button("Show tonight's warnings", ShowWarns, StockIcon.Admin, "Sends you a private message with every player warned tonight.");
                s.ConfirmButton("Reset warnings", () => { warns.Clear(); SaveWarns(); Tell("Warnings reset."); });
                s.Toggle("Share warnings in admin chat", shareWarns);
                s.Slider("Warnings before slay / kick", warnMax, 1, 10);
                s.TextField("Warning reason", warnReason);
            });
            admin.Section(Guid, "Chat alerts", s =>
            {
                s.Toggle("Chat alerts", fAlerts, StockIcon.Admin);
                s.Button("Clear alerts", () => alerts.Clear());
                s.TextField("Alert words", alertWords); s.TextField("Watched players", watchNames);
            });
            admin.Section(Guid, "FIC tags in the kill log", s =>
            {
                s.Toggle("Tag possible FIC kills", fFic, StockIcon.Skull); s.Toggle("On-screen alert", ficAlert);
                s.Button("Show FIC count this round", () => Tell(ficCount.Count == 0 ? "No possible FIC kills yet." : "Possible FIC: " + string.Join(", ", ficCount.OrderByDescending(k => k.Value).Select(k => k.Key + " " + k.Value).ToArray())));
                s.Button("Reset FIC count", () => { ficCount.Clear(); Tell("FIC count reset."); });
                s.Slider("Melee range (m)", ficMeleeRange, 1f, 8f, 0.5f); s.Slider("Shooter at least (m)", ficShooterMin, 0f, 20f, 0.5f);
            });
            admin.Section(Guid, "Teamkill tracker", s =>
            {
                s.Toggle("Count teamkills", fTk, StockIcon.Skull); s.Toggle("Alert on every teamkill", tkAlert); s.Toggle("Count artillery and explosions", tkArty);
                s.Button("Show tonight's teamkills", () => Tell(tks.Count == 0 ? "No teamkills tonight." : "Teamkills tonight: " + string.Join(", ", tks.OrderByDescending(k => k.Value).Select(k => k.Key + " " + k.Value).ToArray())), StockIcon.Admin);
                s.ConfirmButton("Reset teamkills", () => { tks.Clear(); SaveCounts(tkStore, tks); Tell("Teamkill counts reset."); });
                s.Slider("Teamkills before warn / slay / kick", tkMax, 1, 10);
            });

            var players = head.Page(Guid, "Players", StockIcon.Players, true, () => fPlayers.Value);
            players.Section(Guid, "Regiment messages", s =>
            {
                s.Button("Message regiment", () => MessageRegiment(regMessage.Value), StockIcon.Regiment);
                s.Button("Ask to swap sides", () => MessageRegiment((regTag.Value ?? "").Trim() + " please swap sides for the remainder of the event!!"), StockIcon.Regiment);
                s.TextField("Regiment tag", regTag); s.TextField("Message", regMessage);
            });
            players.Section(Guid, "Team count", s => s.Toggle("Show team count", teamCount, StockIcon.Players));

            var mods = PMenu.ModTab(Guid, "Easier Admin", StockIcon.Admin);
            var keysPage = head.Page(Guid, "Hotkeys", StockIcon.Admin, true, () => fHotkeys.Value);
            keysPage.Section(Guid, "Click an action, then press its key (Esc cancels, Backspace clears)", s =>
            {
                foreach (var h in hotkeys) { var hk = h; s.Button(hk.Name, () => StartListening(hk), null, "Hold Ctrl, Shift or Alt with the key for a combination."); }
                s.Button("Show my hotkeys", ShowHotkeys, StockIcon.Admin, "Sends you a private message listing every hotkey.");
                s.ConfirmButton("Reset hotkeys", () => { foreach (var h in hotkeys) h.Key.Value = (KeyboardShortcut)h.Key.DefaultValue; Tell("Hotkeys reset to defaults."); });
            });
            mods.Section(Guid, "Pages", s =>
            {
                s.Toggle("Weapons page", fWeapons); s.Toggle("Fun Settings page", fFun); s.Toggle("Admin page", fAdmin);
                s.Toggle("Players page", fPlayers); s.Toggle("Hotkeys", fHotkeys);
            });
            mods.Section(Guid, "Player row and kill log buttons", s =>
            {
                s.Toggle("Give weapon", fRowGive); s.Toggle("Give loadout 1", fRowLoadout); s.Toggle("Strip weapons", fRowStrip);
                s.Toggle("Quick slays", fRowSlay); s.Toggle("Kill log actions", fKillLog);
            });
            mods.Section(Guid, "Messages", s => s.Toggle("Confirm messages", fFeedback));
            mods.Section(Guid, "About", s => s.Button("About Easier Admin", () => Tell("Easier Admin 1.3.0 by llstarlessll (Discord)")));

            // player row (also in the kill log and map)
            PlayerRow.AddAction(Guid, "Give weapon", StockRowButton.Heal, id => { Give(new[] { id }, new[] { pick.Value.ToString() }); Tell("Gave " + Nice(pick.Value.ToString()) + " to player " + id + "."); }, () => fRowGive.Value);
            PlayerRow.AddAction(Guid, "Give loadout 1", StockRowButton.Heal, id => { Give(new[] { id }, Split(loadouts[0].Value)); Tell("Gave loadout 1 to player " + id + "."); }, () => fRowLoadout.Value);
            PlayerRow.AddAction(Guid, "Strip weapons", StockRowButton.Slap, id => { Rc("carbonPlayers dropAllWeapons " + id); Tell("Stripped the weapons of player " + id + "."); }, () => fRowStrip.Value);
            for (int i = 0; i < 3; i++) { int k = i; PlayerRow.AddAction(Guid, "Slay (reason " + (k + 1) + ")", StockRowButton.Slay, id => { Rc("serverAdmin slay " + id + " " + slayReasons[k].Value); Tell("Slew player " + id + ": " + slayReasons[k].Value); }, () => fRowSlay.Value); }
            PlayerRow.AddAction(Guid, "Warn", StockRowButton.Slap, Warn, () => fWarn.Value);
            PlayerRow.AddAction(Guid, "Kick (warnings)", StockRowButton.Kick, id => KickWarned(id), () => fWarn.Value);
            PlayerRow.AddAction(Guid, "Watch in chat", StockRowButton.Message, WatchToggle, () => fAlerts.Value);
            KillLog.EnableActions(Guid, () => fKillLog.Value);
        }

        // ------------------------------------------------------------------ actions
        static bool Admin { get { return ClientRemoteConsoleAccessManager.loggedOn; } }

        static void Rc(string cmd) { Rc(new[] { cmd }); }
        static void Rc(IEnumerable<string> cmds)
        {
            var c = ClientComponentReferenceManager.ClientInstance;
            if (c == null || c.pMenuPanel == null) { I.Logger.LogWarning("not in a server"); return; }
            var list = cmds.Where(x => !string.IsNullOrEmpty(x)).ToList();
            for (int i = 0; i < list.Count; i += 8)                     // a few commands per line so it never gets too long
                c.pMenuPanel.ManualConsoleExecute("rc " + string.Join(" ; ", list.Skip(i).Take(8).ToArray()));
        }


        struct P { public int Id; public string Name, Tag; public FactionCountry Faction; public PlayerClass Class; public bool Bot, Alive; }

        static List<P> Players()
        {
            var r = new List<P>();
            var c = ClientComponentReferenceManager.ClientInstance;
            if (c == null || c.clientRoundPlayerManager == null) return r;
            var m = c.clientRoundPlayerManager;
            var seen = new HashSet<int>();
            foreach (var proxy in m.roundPlayersList) Add(r, seen, proxy);
            Add(r, seen, m.LocalPlayer);
            return r;
        }
        static void Add(List<P> r, HashSet<int> seen, RoundPlayer p)
        {
            if (p == null || !seen.Add(p.NetworkPlayerID)) return;
            var info = p.PlayerRoundInformation; var d = info != null ? info.InitialDetails : null;
            r.Add(new P
            {
                Id = p.NetworkPlayerID,
                Name = d != null ? (string.IsNullOrEmpty(d.DisplayName) ? d.Name : d.DisplayName) : ("Player " + p.NetworkPlayerID),
                Tag = d != null ? (d.RegimentTag ?? "") : "",
                Faction = p.PlayerStartData != null ? p.PlayerStartData.Faction : default(FactionCountry),
                Class = p.PlayerStartData != null ? p.PlayerStartData.ClassType : default(PlayerClass),
                Bot = info != null && info.IsCarbonPlayer,
                Alive = p.PlayerBase != null && p.PlayerBase.SpawnedAndAlive
            });
        }

        static IEnumerable<int> Targets() { return Players().Where(p => p.Alive && (I.includeBots.Value || !p.Bot)).Select(p => p.Id); }

        // only real weapon names are sent (a typo in a loadout is reported instead of silently doing nothing)
        static string[] Valid(string[] weapons)
        {
            var ok = new List<string>(); var bad = new List<string>();
            foreach (var w in weapons)
            {
                WeaponType t;
                try { t = (WeaponType)Enum.Parse(typeof(WeaponType), w.Trim(), true); ok.Add(t.ToString()); }
                catch { bad.Add(w); }
            }
            if (bad.Count > 0) Tell("Unknown weapon name(s), skipped: " + string.Join(", ", bad.ToArray()));
            return ok.ToArray();
        }

        static void Give(IEnumerable<int> ids, string[] weapons)
        {
            weapons = Valid(weapons);
            var cmds = new List<string>();
            foreach (int id in ids) foreach (var w in weapons) cmds.Add("carbonPlayers pickupWeapon " + id + " " + w.Trim());
            Rc(cmds);
        }
        static void GiveAll(string[] weapons) { var t = Targets().ToList(); weapons = Valid(weapons); if (weapons.Length == 0) { Tell("Nothing to give: the loadout is empty or has no valid weapon names."); return; } Give(t, weapons); Tell("Gave " + string.Join(", ", weapons.Select(Nice).ToArray()) + " to " + t.Count + " living players."); }
        static void TakeAll(string weapon) { var t = Targets().ToList(); Rc(t.Select(id => "carbonPlayers dropWeapon " + id + " " + weapon)); Tell("Took " + Nice(weapon) + " from " + t.Count + " living players."); }
        static void StripAll() { var t = Targets().ToList(); Rc(t.Select(id => "carbonPlayers dropAllWeapons " + id)); Tell("Stripped the weapons of " + t.Count + " living players."); }

        static void MessageRegiment(string text)
        {
            string tag = (I.regTag.Value ?? "").Trim();
            if (tag.Length == 0) { Tell("Set a regiment tag first."); return; }
            var ids = Players().Where(p => !p.Bot && string.Equals(p.Tag.Trim(), tag, StringComparison.OrdinalIgnoreCase)).Select(p => p.Id).ToList();
            Rc(ids.Select(id => "serverAdmin privateMessage " + id + " " + text));
            Tell(ids.Count == 0 ? "Nobody wearing the tag " + tag + " is in the server." : "Messaged " + ids.Count + " players in " + tag + ".");
        }

        void StartListening(Hotkey h)
        {
            listening = h; listenUntil = Time.unscaledTime + 10f;
            Tell("Press the key for: " + h.Name + " (now " + KeyText(h.Key.Value) + "). Esc cancels, Backspace clears.");
        }

        void ShowHotkeys()
        {
            var set = hotkeys.Where(h => h.Key.Value.MainKey != KeyCode.None).Select(h => KeyText(h.Key.Value) + " = " + h.Name).ToArray();
            Tell(set.Length == 0 ? "No hotkeys set." : "Hotkeys: " + string.Join(" | ", set));
        }

        static readonly KeyCode[] Mods = { KeyCode.LeftControl, KeyCode.RightControl, KeyCode.LeftShift, KeyCode.RightShift, KeyCode.LeftAlt, KeyCode.RightAlt };
        static KeyCode[] allKeys;

        void Listen()
        {
            if (Time.unscaledTime > listenUntil) { Tell("Hotkey not changed (no key pressed)."); listening = null; return; }
            if (!Input.anyKeyDown) return;
            if (Input.GetKeyDown(KeyCode.Escape)) { Tell("Hotkey not changed."); listening = null; return; }
            if (Input.GetKeyDown(KeyCode.Backspace)) { listening.Key.Value = KeyboardShortcut.Empty; Tell(listening.Name + ": cleared."); listening = null; return; }
            if (allKeys == null) allKeys = (KeyCode[])Enum.GetValues(typeof(KeyCode));
            foreach (var k in allKeys)
            {
                if (k == KeyCode.None || k == KeyCode.Mouse0 || k == KeyCode.Mouse1 || Mods.Contains(k) || !Input.GetKeyDown(k)) continue;
                var mods = new List<KeyCode>();
                if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl)) mods.Add(KeyCode.LeftControl);
                if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) mods.Add(KeyCode.LeftShift);
                if (Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt)) mods.Add(KeyCode.LeftAlt);
                var sc = new KeyboardShortcut(k, mods.ToArray());
                foreach (var o in hotkeys) if (o != listening && o.Key.Value.Equals(sc)) { o.Key.Value = KeyboardShortcut.Empty; Tell(KeyText(sc) + " was on '" + o.Name + "', moved it."); }
                if (k == KeyCode.F6 || k == KeyCode.LeftBracket || k == KeyCode.RightBracket) Tell("Note: " + k + " is also used by AdminHelper.");
                listening.Key.Value = sc;
                Tell(listening.Name + " = " + KeyText(sc));
                listening = null; return;
            }
        }

        static bool Typing()
        {
            var es = UnityEngine.EventSystems.EventSystem.current;
            var go = es != null ? es.currentSelectedGameObject : null;
            return go != null && (go.GetComponent<UnityEngine.UI.InputField>() != null || go.GetComponent<TMPro.TMP_InputField>() != null);
        }

        void RunMacro(int i) { var c = Split(macroText[i].Value, ';'); if (c.Length == 0) { Tell("Macro " + (i + 1) + " is empty."); return; } Rc(c); Tell("Ran macro " + (i + 1) + "."); }

        void Schedule(string cmd, int delay)
        {
            if (string.IsNullOrEmpty((cmd ?? "").Trim())) { Tell("Type a command first."); return; }
            scheduled.Add(new KeyValuePair<float, string>(Time.time + delay, cmd));
            Tell("Scheduled in " + delay + " s: " + cmd);
        }

        // the page cannot read the server, so every session starts showing the game's defaults
        void ResetFunDisplay()
        {
            suppress = true;
            try
            {
                foreach (var e in new[] { runSpeed, jumpForce, explosionSize, explosionKnock, ragdoll, dmgScale, walkSpeed, horseJump, cannonLoad }) e.Value = (float)e.DefaultValue;
                foreach (var e in new[] { explosive, infiniteAmmo, godMode, fallDamage, allowFiring, allowArty, allowBlock, bulletDrop, infRange, horseAll, firstPerson }) e.Value = (bool)e.DefaultValue;
            }
            finally { suppress = false; }
        }

        void ApplyAllFun()
        {
            var inv = System.Globalization.CultureInfo.InvariantCulture; var c = new List<string>();
            c.Add("set characterRunSpeed " + runSpeed.Value.ToString("0.##", inv)); c.Add("set characterJumpForce " + jumpForce.Value.ToString("0.##", inv));
            c.Add("set explosionScaleMultiplier " + explosionSize.Value.ToString("0.##", inv)); c.Add("set explosionKnockbackForceMultiplier " + explosionKnock.Value.ToString("0.##", inv));
            c.Add("set ragdollForceMultiplier " + ragdoll.Value.ToString("0.##", inv));
            c.Add("set characterExplosiveFirearms " + (explosive.Value ? "true" : "false")); c.Add("set characterInfiniteFirearmAmmo " + (infiniteAmmo.Value ? "true" : "false"));
            c.Add("set characterGodMode " + (godMode.Value ? "true" : "false")); c.Add("set characterFallDamageEnabled " + (fallDamage.Value ? "true" : "false"));
            c.Add("set allowFiring " + (allowFiring.Value ? "true" : "false")); c.Add("set allowArtyFiring " + (allowArty.Value ? "true" : "false"));
            c.Add("set characterWeaponDamageScale " + dmgScale.Value.ToString("0.##", inv)); c.Add("set characterWalkSpeed " + walkSpeed.Value.ToString("0.##", inv));
            c.Add("set vehicleJumpHeightMultiplier " + horseJump.Value.ToString("0.##", inv)); c.Add("set cannonLoadingSpeedMultiplier " + cannonLoad.Value.ToString("0.##", inv));
            c.Add("set allowBlocking " + (allowBlock.Value ? "true" : "false")); c.Add("set characterWeaponFirearmApplyDrop " + (bulletDrop.Value ? "true" : "false"));
            c.Add("set characterWeaponInfiniteRange " + (infRange.Value ? "true" : "false")); c.Add("set vehicleHorseForAll " + (horseAll.Value ? "true" : "false"));
            c.Add("set forceFirstPersonMode " + (firstPerson.Value ? "true" : "false"));
            Rc(c); Tell("Sent every fun setting to the server.");
        }

        void ResetFun()
        {
            Rc("set default");
            suppress = true;
            try
            {
                foreach (var e in new[] { runSpeed, jumpForce, explosionSize, explosionKnock, ragdoll, dmgScale, walkSpeed, horseJump, cannonLoad }) e.Value = (float)e.DefaultValue;
                foreach (var e in new[] { explosive, infiniteAmmo, godMode, fallDamage, allowFiring, allowArty, allowBlock, bulletDrop, infRange, horseAll, firstPerson }) e.Value = (bool)e.DefaultValue;
            }
            finally { suppress = false; }
            Tell("Game settings reset to default.");
        }

        static string[] Split(string s, char sep = ',') { return (s ?? "").Split(sep).Select(x => x.Trim()).Where(x => x.Length > 0).ToArray(); }
        static string Nice(string w) { return w.Replace("Frontlines_", "WW1 ").Replace("Spontoon_", "").Replace("Sword_", "").Replace("Axe2H_", "").Replace("Axe1H_", "").Replace("_", " "); }
        static string Short(string s) { return s.Length > 14 ? s.Substring(0, 14) : s; }


        // ------------------------------------------------------------------ 1.3.0: warnings
        static string NameOf(int id) { var p = Players().FirstOrDefault(x => x.Id == id); return p.Name ?? ("Player " + id); }
        static string Today() { return DateTime.Now.AddHours(-6).ToString("yyyy-MM-dd"); }   // a night that runs past midnight still counts as one night
        void LoadWarns()
        {
            warns.Clear();
            var parts = (warnStore.Value ?? "").Split('|');
            if (parts.Length < 2 || parts[0] != Today()) return;
            foreach (var kv in parts[1].Split(';')) { int i = kv.LastIndexOf('='); int n; if (i > 0 && int.TryParse(kv.Substring(i + 1), out n)) warns[kv.Substring(0, i)] = n; }
        }
        static void SaveWarns() { I.warnStore.Value = Today() + "|" + string.Join(";", warns.Select(k => k.Key.Replace(";", "").Replace("|", "").Replace("=", "") + "=" + k.Value).ToArray()); }
        static void LoadCounts(ConfigEntry<string> store, Dictionary<string, int> d)
        {
            d.Clear();
            var parts = (store.Value ?? "").Split('|');
            if (parts.Length < 2 || parts[0] != Today()) return;
            foreach (var kv in parts[1].Split(';')) { int i = kv.LastIndexOf('='); int n; if (i > 0 && int.TryParse(kv.Substring(i + 1), out n)) d[kv.Substring(0, i)] = n; }
        }
        static void SaveCounts(ConfigEntry<string> store, Dictionary<string, int> d) { store.Value = Today() + "|" + string.Join(";", d.Select(k => k.Key.Replace(";", "").Replace("|", "").Replace("=", "") + "=" + k.Value).ToArray()); }
        static void ShowWarns() { Tell(warns.Count == 0 ? "No warnings tonight." : "Warnings tonight: " + string.Join(", ", warns.OrderByDescending(k => k.Value).Select(k => k.Key + " " + k.Value).ToArray())); }

        void Warn(int id)
        {
            if ((warnStore.Value ?? "").Split('|')[0] != Today()) warns.Clear();
            string name = NameOf(id);
            int n; warns.TryGetValue(name, out n); n++; warns[name] = n; SaveWarns();
            int max = warnMax.Value;
            Rc("serverAdmin privateMessage " + id + " Admin warning " + n + "/" + max + ": " + warnReason.Value);
            AdminChat("[EA] WARN " + n + "/" + max + " " + name + " (#" + id + "): " + warnReason.Value);   // other admins see it, and their Easier Admin counts it too
            Tell("Warned " + name + " (" + Ordinal(n) + " warning).");
            if (n >= max) Offer(id, name, n);
        }
        static string Ordinal(int n) { int t = n % 100; string suf = (t >= 11 && t <= 13) ? "th" : n % 10 == 1 ? "st" : n % 10 == 2 ? "nd" : n % 10 == 3 ? "rd" : "th"; return n + suf; }
        static void Offer(int id, string name, int n)
        {
            offerId = id; offerName = name; offerUntil = Time.unscaledTime + 30f; offerWarn = false;
            offerText = "<b>" + name + "</b> has had their <b>" + Ordinal(n) + "</b> warning. Slay or kick?"; offerReason = "Too many warnings: " + I.warnReason.Value;
            AddAlert("<color=#ff6a5a><b>" + Ordinal(n) + " warning</b></color> " + name);
        }
        static void OfferTk(int id, string name, int n)
        {
            offerId = id; offerName = name; offerUntil = Time.unscaledTime + 30f; offerWarn = I.fWarn.Value;
            offerText = "<b>" + name + "</b> has <b>" + n + "</b> teamkills tonight. Warn, slay or kick?"; offerReason = "Teamkilling (" + n + " teamkills)";
        }
        static int kickArmId = -1; static float kickArmUntil;
        void KickWarned(int id)
        {
            string name = NameOf(id); int n; warns.TryGetValue(name, out n);
            if (n < warnMax.Value) { Tell(name + " has " + n + " of " + warnMax.Value + " warnings. Warn first, or kick from the normal Kick button."); return; }
            if (kickArmId != id || Time.unscaledTime > kickArmUntil) { kickArmId = id; kickArmUntil = Time.unscaledTime + 5f; Tell("Click Kick (warnings) again within 5 seconds to kick " + name + "."); AddAlert("Click <b>Kick (warnings)</b> again to kick " + name); return; }
            kickArmId = -1;
            Rc("serverAdmin kick " + id + " " + n + " warnings: " + warnReason.Value);
            AdminChat("[EA] KICKED " + name + " after " + n + " warnings");
            Tell("Kicked " + name + ".");
        }

        // admin chat: only logged-in admins can see it
        static void AdminChat(string text)
        {
            if (!I.shareWarns.Value) return;          // off by default: nothing is posted unless the admin turned sharing on
            try
            {
                var nv = uLinkNetworkConnectionsCollection.LocalNetworkView;
                var st = nv.ObtainBitstreamForRPC();
                SendChatMessagePacket.WriteBitStream(st, text, (int)TextChatChannel.Admin);
                nv.SendRPCToServer("scm", st);
            }
            catch (Exception e) { I.Logger.LogWarning("admin chat: " + e.Message); }
        }

        // ------------------------------------------------------------------ 1.3.0: chat alerts
        void WatchToggle(int id)
        {
            string name = NameOf(id);
            var list = Split(watchNames.Value).ToList();
            if (list.Any(x => string.Equals(x, name, StringComparison.OrdinalIgnoreCase))) { list.RemoveAll(x => string.Equals(x, name, StringComparison.OrdinalIgnoreCase)); Tell("Stopped watching " + name + " in chat."); }
            else { list.Add(name); Tell("Watching " + name + " in chat."); }
            watchNames.Value = string.Join(", ", list.ToArray());
        }
        static void AddAlert(string text)
        {
            alerts.Insert(0, new Alert { Until = Time.unscaledTime + 25f, Text = DateTime.Now.ToString("HH:mm") + "  " + text });
            if (alerts.Count > 6) alerts.RemoveAt(alerts.Count - 1);
        }
        static string Clean(string s) { return System.Text.RegularExpressions.Regex.Replace(s ?? "", "<[^>]*>", ""); }

        static void ChatPrefix(int playerID, ref string textEntry, TextChatEntryType entryType, TextChatChannel channel)
        {
            try
            {
                if (I == null || !Admin || string.IsNullOrEmpty(textEntry)) return;
                string plain = Clean(textEntry);
                // warnings from other admins' Easier Admin (admin chat)
                if (channel == TextChatChannel.Admin && plain.Contains("[EA] WARN "))
                {
                    var m = System.Text.RegularExpressions.Regex.Match(plain, @"\[EA\] WARN (\d+)/(\d+) (.+?) \(#(\d+)\)");
                    if (m.Success && playerID != LocalId())
                    {
                        int n = int.Parse(m.Groups[1].Value); string name = m.Groups[3].Value; int old; warns.TryGetValue(name, out old);
                        if (n > old) { warns[name] = n; SaveWarns(); }
                        if (n >= int.Parse(m.Groups[2].Value)) Offer(int.Parse(m.Groups[4].Value), name, n);
                    }
                    return;
                }
                if (!I.fAlerts.Value || entryType != TextChatEntryType.Normal || playerID < 0 || playerID == LocalId()) return;
                string sender = NameOf(playerID);
                string lower = plain.ToLowerInvariant();
                string hit = null;
                if (Split(I.watchNames.Value).Any(w => string.Equals(w, sender, StringComparison.OrdinalIgnoreCase))) hit = "watched";
                if (hit == null) foreach (var w in Split(I.alertWords.Value)) if (System.Text.RegularExpressions.Regex.IsMatch(lower, @"(^|\W)" + System.Text.RegularExpressions.Regex.Escape(w.ToLowerInvariant()) + @"($|\W)")) { hit = w; break; }
                if (hit == null) return;
                textEntry = "<mark=#ffcc3355><color=#ffe08a>" + textEntry + "</color></mark>";
                AddAlert("<color=#ffcc33>" + sender + "</color> (" + channel + "): " + (plain.Length > 90 ? plain.Substring(0, 90) + "..." : plain));
            }
            catch (Exception e) { I.Logger.LogWarning("chat alert: " + e.Message); }
        }
        static int LocalId() { var c = ClientComponentReferenceManager.ClientInstance; return c != null && c.clientRoundPlayerManager != null && c.clientRoundPlayerManager.LocalPlayer != null ? c.clientRoundPlayerManager.LocalPlayer.NetworkPlayerID : -2; }

        // ------------------------------------------------------------------ 1.3.0: FIC tags
        // FIC = a firearm kill on an enemy who was in melee with the shooter's own side (a teammate within MeleeRange of the victim),
        // fired from outside that melee (the shooter at least ShooterDistance away).
        static string ficTag;
        static void ScorePrefix(ClientRoundPlayer killer, ClientRoundPlayer victim, ScorableAction scorableAction)
        {
            ficTag = null;
            try
            {
                if (I == null || !Admin || killer == null || victim == null || killer == victim) return;
                var a = scorableAction as PlayerKilledPlayerScorableAction;
                if (a == null) return;
                bool sameSide = killer.PlayerStartData != null && victim.PlayerStartData != null && killer.PlayerStartData.Faction == victim.PlayerStartData.Faction;
                if (a.TeamKill || sameSide) { if (I.fTk.Value) TrackTk(killer, victim, a); return; }
                if (!I.fFic.Value || a.KilledMethod != KilledMethod.FirearmWeapon) return;
                if (killer.PlayerStartData == null || victim.PlayerStartData == null) return;
                if (victim.PlayerTransform == null || killer.PlayerTransform == null) return;
                Vector3 vp = victim.PlayerTransform.position;
                float shooterDist = a.Distance > 0f ? a.Distance : Vector3.Distance(killer.PlayerTransform.position, vp);
                if (shooterDist < I.ficShooterMin.Value) return;
                var c = ClientComponentReferenceManager.ClientInstance; var m = c.clientRoundPlayerManager;
                var side = killer.PlayerStartData.Faction; float range = I.ficMeleeRange.Value; string mate = null; float best = range;
                foreach (RoundPlayer p in m.roundPlayersList.Cast<RoundPlayer>().Concat(new RoundPlayer[] { m.LocalPlayer }))
                {
                    if (p == null || p == killer || p == victim || p.PlayerBase == null || !p.PlayerBase.SpawnedAndAlive || p.PlayerStartData == null || p.PlayerStartData.Faction != side || p.PlayerTransform == null) continue;
                    float d = Vector3.Distance(p.PlayerTransform.position, vp);
                    if (d <= best) { best = d; mate = PName(p); }
                }
                if (mate == null) return;
                string kn = PName(killer);
                int n; ficCount.TryGetValue(kn, out n); ficCount[kn] = n + 1;
                ficTag = " <color=#ff4a3d><b>[FIC?]</b></color>";
                if (I.ficAlert.Value) AddAlert("<color=#ff4a3d><b>FIC?</b></color> " + kn + " shot " + PName(victim) + " at " + shooterDist.ToString("0") + " m, " + mate + " was " + best.ToString("0.0") + " m from them (" + (n + 1) + " this round)");
            }
            catch (Exception e) { I.Logger.LogWarning("fic: " + e.Message); }
        }
        static void TrackTk(ClientRoundPlayer killer, ClientRoundPlayer victim, PlayerKilledPlayerScorableAction a)
        {
            bool handOrGun = a.KilledMethod == KilledMethod.FirearmWeapon || a.KilledMethod == KilledMethod.MeleeWeapon;
            if (!handOrGun && !I.tkArty.Value) return;
            if ((I.tkStore.Value ?? "").Split('|')[0] != Today()) tks.Clear();
            string kn = PName(killer);
            int n; tks.TryGetValue(kn, out n); n++; tks[kn] = n; SaveCounts(I.tkStore, tks);
            ficTag = " <color=#ff9a3d><b>[TK " + n + "]</b></color>";
            string how = a.KilledMethod == KilledMethod.FirearmWeapon ? "shot" : a.KilledMethod == KilledMethod.MeleeWeapon ? "melee" : a.KilledMethod.ToString();
            if (I.tkAlert.Value) AddAlert("<color=#ff9a3d><b>Teamkill</b></color> " + kn + " killed " + PName(victim) + " (" + how + ", " + Ordinal(n) + " tonight)");
            if (n >= I.tkMax.Value) OfferTk(killer.NetworkPlayerID, kn, n);
        }
        static string PName(RoundPlayer p) { var d = p.PlayerRoundInformation != null ? p.PlayerRoundInformation.InitialDetails : null; return d != null ? (string.IsNullOrEmpty(d.DisplayName) ? d.Name : d.DisplayName) : ("Player " + p.NetworkPlayerID); }
        static void KillLogPrefix(ref string killerName) { if (ficTag != null) { killerName = killerName + ficTag; ficTag = null; } }

        void Patch()
        {
            var h = new Harmony(Guid);
            TryPatch(h, typeof(ClientChatHandler), "AddChatEntry", new[] { typeof(int), typeof(string), typeof(TextChatEntryType), typeof(TextChatChannel), typeof(string) }, "ChatPrefix");
            TryPatch(h, typeof(ScoreLogUI), "DisplayScore", null, "ScorePrefix");
            TryPatch(h, typeof(UIAdminPlayerKillLogPanel), "AddKillLog", null, "KillLogPrefix");
        }
        void TryPatch(Harmony h, Type t, string method, Type[] args, string prefix)
        {
            try
            {
                var target = args != null ? AccessTools.Method(t, method, args) : AccessTools.Method(t, method);
                h.Patch(target, prefix: new HarmonyMethod(typeof(EasierAdminPlugin), prefix));
            }
            catch (Exception e) { Logger.LogWarning("Could not hook " + t.Name + "." + method + " (that feature is off): " + e.Message); }
        }

        // ------------------------------------------------------------------ loop
        void Update()
        {
            try
            {
                if (!Admin) return;
                if (listening != null) Listen();
                else if (fHotkeys.Value && !Typing())
                    foreach (var h in hotkeys) if (h.Key.Value.MainKey != KeyCode.None && h.Key.Value.IsDown()) { h.Run(); break; }

                float now = Time.time;
                if (pendingSet.Count > 0)
                    foreach (var k in pendingSet.Keys.ToList()) if (Time.unscaledTime >= pendingSet[k].Key) { Rc(pendingSet[k].Value); pendingSet.Remove(k); }
                for (int i = scheduled.Count - 1; i >= 0; i--)
                    if (now >= scheduled[i].Key) { Rc(Split(scheduled[i].Value, ';')); scheduled.RemoveAt(i); }

                if (now >= nextPoll)
                {
                    nextPoll = now + 0.5f;
                    var alive = new HashSet<int>();
                    foreach (var p in Players()) if (p.Alive && (includeBots.Value || !p.Bot)) alive.Add(p.Id);
                    if (keepGiving.Value) foreach (int id in alive) if (!wasAlive.Contains(id)) pendingGive.Add(new KeyValuePair<float, int>(now + 1f, id));
                    wasAlive.Clear(); foreach (int id in alive) wasAlive.Add(id);
                }
                for (int i = pendingGive.Count - 1; i >= 0; i--)
                    if (now >= pendingGive[i].Key) { Give(new[] { pendingGive[i].Value }, new[] { pick.Value.ToString() }); pendingGive.RemoveAt(i); }
            }
            catch (Exception e) { Logger.LogWarning("update: " + e.Message); }
        }

        void OnGUI()
        {
            if (!Admin) return;
            try { DrawAlerts(); } catch { }
            if (!teamCount.Value) return;
            try
            {
                if (Time.unscaledTime >= cacheAt) { cache = Players().Where(p => p.Alive).ToList(); cacheAt = Time.unscaledTime + 0.5f; }
                var ps = cache;
                var lines = new List<string>();
                foreach (var f in ps.GroupBy(p => p.Faction))
                {
                    lines.Add("<b>" + f.Key + ": " + f.Count() + "</b>");
                    lines.Add("  " + string.Join(", ", f.GroupBy(p => p.Class).OrderByDescending(g => g.Count()).Select(g => g.Key + " " + g.Count()).ToArray()));
                    var regs = f.Where(p => p.Tag.Length > 0).GroupBy(p => p.Tag).OrderByDescending(g => g.Count()).Take(4).Select(g => g.Key + " " + g.Count()).ToArray();
                    if (regs.Length > 0) lines.Add("  " + string.Join(", ", regs));
                }
                var style = new GUIStyle(GUI.skin.box) { alignment = TextAnchor.UpperLeft, richText = true, fontSize = 13, wordWrap = true };
                GUI.Box(new Rect(10, 120, 360, 20 + 18 * lines.Count), "Team count\n" + string.Join("\n", lines.ToArray()), style);
            }
            catch { }
        }
        void DrawAlerts()
        {
            float now = Time.unscaledTime;
            alerts.RemoveAll(a => a.Until < now);
            float w = 460, x = Screen.width - w - 14, y = 70;
            var style = new GUIStyle(GUI.skin.box) { alignment = TextAnchor.UpperLeft, richText = true, fontSize = 13, wordWrap = true, padding = new RectOffset(8, 8, 6, 6) };
            if (offerId >= 0 && now < offerUntil)
            {
                GUI.Box(new Rect(x, y, w, 64), offerText, style);
                float bx = x + 8, bw = offerWarn ? 104 : 136;
                if (offerWarn && GUI.Button(new Rect(bx, y + 32, bw, 24), "Warn")) { int id = offerId; offerId = -1; string keep = warnReason.Value; try { warnReason.Value = "Teamkilling"; Warn(id); } finally { warnReason.Value = keep; } }
                if (offerWarn) bx += bw + 6;
                if (GUI.Button(new Rect(bx, y + 32, bw, 24), "Slay")) { Rc("serverAdmin slay " + offerId + " " + offerReason); Tell("Slew " + offerName + "."); offerId = -1; }
                bx += bw + 6;
                if (GUI.Button(new Rect(bx, y + 32, bw, 24), "Kick")) { Rc("serverAdmin kick " + offerId + " " + offerReason); AdminChat("[EA] KICKED " + offerName + ": " + offerReason); Tell("Kicked " + offerName + "."); offerId = -1; }
                bx += bw + 6;
                if (GUI.Button(new Rect(bx, y + 32, bw, 24), "Dismiss")) offerId = -1;
                y += 72;
            }
            else if (offerId >= 0) offerId = -1;
            if (alerts.Count == 0) return;
            string text = string.Join("\n", alerts.Select(a => a.Text).ToArray());
            float hgt = style.CalcHeight(new GUIContent(text), w);
            GUI.Box(new Rect(x, y, w, hgt), text, style);
        }
    }
}
