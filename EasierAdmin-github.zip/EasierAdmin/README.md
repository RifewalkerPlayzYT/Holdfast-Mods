# Easier Admin

**Created by llstarlessll (Discord)**

A client-side admin helper for **Holdfast: Nations At War**, built with BepInEx and [RyLib](https://github.com/Ryannlt/RyLib). It adds an **Easier Admin** tab to the P menu with one-click buttons for the jobs admins normally type `rc` commands for: giving weapons to everyone or one player, loadouts, fun round game settings, scheduled commands, macros, broadcasts, quick slays, regiment messages and in-game hotkeys. It only works after `rc login`.

**Download:** [Thunderstore](https://thunderstore.io/c/holdfast-nations-at-war/p/Holdfast_Modders/EasierAdmin/) (install with r2modman).
The full user guide is in [`thunderstore/README.md`](thunderstore/README.md).

## Repository layout

| Path | What it is |
| --- | --- |
| `src/EasierAdmin.cs` | The whole plugin. |
| `EasierAdmin.csproj` | Build file. |
| `thunderstore/` | `manifest.json`, `icon.png` and the user guide that go into the Thunderstore package. |
| `CHANGELOG.md` | Version history. |

No game, BepInEx or RyLib files are included; the build uses your own copies.

## Building

Requirements: the game, an r2modman profile with BepInExPack_Holdfast and RyLib installed, and the [.NET SDK](https://dotnet.microsoft.com/download).

```
dotnet build -c Release
```

If your game or r2modman profile is somewhere else:

```
dotnet build -c Release -p:GameDir="D:\SteamLibrary\steamapps\common\Holdfast Nations At War" -p:ProfileDir="C:\Users\you\AppData\Roaming\r2modmanPlus-local\HoldfastNationsAtWar\profiles\Default"
```

The DLL is written to `bin/Release/net472/EasierAdmin.dll`.

## Packaging for Thunderstore

Make a zip containing:

```
manifest.json
icon.png
README.md          (thunderstore/README.md)
CHANGELOG.md
BepInEx/plugins/EasierAdmin/EasierAdmin.dll
```

Bump `version_number` in `thunderstore/manifest.json` for every upload.

## License

[MIT](LICENSE)
